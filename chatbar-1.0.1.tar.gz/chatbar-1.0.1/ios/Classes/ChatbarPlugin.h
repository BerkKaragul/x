#import <Flutter/Flutter.h>

@interface ChatbarPlugin : NSObject<FlutterPlugin>
@end
