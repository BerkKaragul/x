## 1.0.1
readme fix

## 1.0.0
breaking changes
* changed profilePic to type Image
* changed status to Widget


## 0.0.7

* example/readme.md updated again
